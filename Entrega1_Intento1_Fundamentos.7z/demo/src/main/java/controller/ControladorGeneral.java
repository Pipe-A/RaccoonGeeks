package controller;

import model.Administrativo;
import model.Estudiante;
import model.Profesor;

import java.util.Map;

public class ControladorGeneral {
    ControladorAdministrativo controlAdmin = new ControladorAdministrativo();
    ControladorProfesor controlProfe = new ControladorProfesor();
    ControladorEstudiante controlEstu = new ControladorEstudiante();
    //Map<,Curso> listaCursos = new Map();

    public ControladorProfesor getControlProfe() {
        return controlProfe;
    }
    public ControladorEstudiante getControlEstu() {
        return controlEstu;
    }
    public ControladorAdministrativo getControlAdmin() { return controlAdmin; }

    public void comprobarTipoUsuario(String usuario, String contrasenna){
        Estudiante estudianteEncontrado = this.controlEstu.buscarEstudiante(usuario);
        Profesor profesorEncontrado = this.controlProfe.buscarProfesor(usuario);
        Administrativo administrativoEncontrado = this.controlAdmin.buscarAdministradores(usuario);
        if(estudianteEncontrado.getUsuarioEstud().equals(usuario) && estudianteEncontrado.getContrasennaEstud().equals(contrasenna)){
            //Redirecciona al módulo de estudiantes.
        } else if(profesorEncontrado.getUsuarioProfe().equals(usuario) && profesorEncontrado.getContrasennaProfe().equals(contrasenna)){
            //Redirección modulo profe.
        } else if(administrativoEncontrado.getUsuarioAdmin().equals(usuario) && administrativoEncontrado.getContrasennaAdmin().equals(contrasenna)){
            //redirección modulo administrativo
        }
        else{
            System.out.println("No existe usuario");
        }

    }

    public void asignarEstudiante(Estudiante estudiante){
        //si el estudiante existe, asignar (put) al curso
    }

    public void asingarProfesor(Profesor profesor){
        //si el profesor existe, asignar (put) al curso
    }

    public void asignarMonitor(Profesor monitor){
        //si el estudiante existe, darle el poder del profesor:v y asignar (put) al curso
    }
}
