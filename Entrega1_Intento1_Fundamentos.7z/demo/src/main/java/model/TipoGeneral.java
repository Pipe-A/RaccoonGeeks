package model;

public enum TipoGeneral {
    PROFESOR,
    ESTUDIANTE,
    ADMINISTRATIVO;
}
