package model;

public enum TipoProfesor {
    DE_PLANTA,
    DE_CATEDRA,
    MONITOR;
}
