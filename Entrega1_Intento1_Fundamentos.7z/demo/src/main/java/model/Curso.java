package model;

public class Curso {
}
